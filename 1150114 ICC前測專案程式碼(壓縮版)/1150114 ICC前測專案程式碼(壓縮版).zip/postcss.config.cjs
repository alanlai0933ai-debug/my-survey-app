module.exports = {
  plugins: {
    tailwindcss: {}, // 👈 v3 只需要這樣寫，不需要引號或 @ 前綴
    autoprefixer: {},
  },
}